﻿using System;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Text;

namespace TrippinExercise
{
    class Program
    {
        private static HttpClient HttpClient = new HttpClient { BaseAddress = new Uri("https://services.odata.org/TripPinRESTierService/(S(x04bmi0o5s2hqw5feq1lsln3))/") };

        static async Task Main(string[] args)
        {
            if(args.Length == 1)
            {
                var jsonText = await GetUserFromJsonFile(args[0]);
                var jsonUsers = JsonSerializer.Deserialize<FileUser[]>(jsonText);
                
                var trippinUsers = await Get();

                await AddUser(jsonUsers, trippinUsers);

                return;
            }
        }

        private static async Task AddUser(FileUser[] jsonUsers, TrippinUser[] trippinUsers)
        {
            for(int i = 0; i < trippinUsers.Length; i++)
            {
                if (i <= jsonUsers.Length)
                {
                    /*
                    if (jsonUsers[i].UserName != trippinUsers[i].UserName)
                    {
                        using (HttpResponseMessage addResponse = await HttpClient.PostAsync("People", new StringContent(JsonSerializer.Serialize(new
                        {
                            UserName = jsonUsers[i].UserName,
                            FirstName = jsonUsers[i].FirstName,
                            LastName = jsonUsers[i].LastName,
                            Emails = new[] {
                                jsonUsers[i].Emails
                            },
                            AddressInfo = new[] {
                                new {
                                    Address = jsonUsers[i].Address,
                                    City = new {
                                        Name = jsonUsers[i].CityName,
                                        CountryRegion = jsonUsers[i].Country,
                                        Region = jsonUsers[i].Country
                                    }
                                }
                            }
                        })))) ;
                    }*/
                }
            }
        }

        public static async Task<TrippinUser[]> Get()
        {
            var trippinUserResponse = await HttpClient.GetAsync("People");
            trippinUserResponse.EnsureSuccessStatusCode();
            var responseBody = await trippinUserResponse.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<TrippinUser[]>(responseBody);
        }

        public static async Task Post(TrippinUser trippinUser)
        {
            var content = new StringContent(JsonSerializer.Serialize(trippinUser), Encoding.UTF8, "application/json");
            var trippinResponse = await HttpClient.PostAsync("People", content);
            trippinResponse.EnsureSuccessStatusCode();
        }

        private static async Task<string> GetUserFromJsonFile(string file)
        {
            string text;
            try
            {
                text = await File.ReadAllTextAsync(file);
            }
            catch (FileNotFoundException ex)
            {
                Console.Error.WriteLine("File not founded: " + ex.ToString());
                throw;
            }
            return text;
        }
    }
}
